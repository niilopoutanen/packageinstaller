﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace WPFinstaller
{
    internal class Animations
    {
        //private Storyboard storyboard;

        //public async Task InstallButtonAnim(string installbutton)
        //{
        //    DoubleAnimation movepos = new DoubleAnimation();
        //    movepos.From = 400;
        //    movepos.To = 120;
        //    movepos.Duration = TimeSpan.FromSeconds(1);
        //    movepos.FillBehavior = FillBehavior.HoldEnd;

        //    storyboard = new Storyboard();
        //    storyboard.Children.Add(movepos);
        //    Storyboard.SetTargetName(movepos, installbutton);
        //    Storyboard.SetTargetProperty(movepos, new PropertyPath(Border.WidthProperty));
        //    storyboard.Begin(this);
        //    await Task.Delay(1000);
        //}
    }
}
